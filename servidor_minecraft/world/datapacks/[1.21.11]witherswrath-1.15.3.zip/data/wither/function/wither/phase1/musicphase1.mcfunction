execute at @e[type=minecraft:wither,limit=1,sort=nearest] as @e[type=minecraft:player,distance=..200] at @s run playsound minecraft:wither.phase1 record @a ~ ~ ~ 1 1

execute if score witherCount witherCount matches 1.. run schedule function wither:wither/phase1/musicphase1 139s
