execute at @e[type=minecraft:wither,limit=1,sort=nearest] as @e[type=minecraft:player,distance=..200] at @s run playsound minecraft:wither.phase2 record @a ~ ~ ~ 1 1

execute if score witherCount witherCount matches 1.. run schedule function wither:wither/phase2/musicphase2 233s
