execute as @s run function wither:wither/toggle/toggle
