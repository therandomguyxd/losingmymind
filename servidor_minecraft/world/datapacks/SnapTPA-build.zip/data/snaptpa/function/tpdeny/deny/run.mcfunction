
playsound minecraft:entity.experience_orb.pickup ambient @s ~ ~ ~ 0.25 1

$execute unless data storage stpa:pending _$(to_pid)[{from_pid: $(from_pid)}] run return run tellraw @s {translate:"stpa.error.no_teleport_request",fallback:"You Don't Have Any Teleport Request.",color:"red"}

$tellraw @a[scores={playerID=$(from_pid)}] [{selector:"@a[scores={playerID=$(to_pid)}]",color:"green"},{translate:"stpa.deny.notify_sender",fallback:" Denied Your Teleport Request.",color:"gold"}]
$tellraw @a[scores={playerID=$(to_pid)}] [{translate:"stpa.deny.notify_receiver.prefix",fallback:"Denied ",color:"gold"},{selector:"@a[scores={playerID=$(from_pid)}]",color:"green"},{translate:"stpa.deny.notify_receiver.suffix",fallback:"'s Teleport Request.",color:"gold"}]

$data remove storage stpa:pending _$(to_pid)[{from_pid: $(from_pid)}]
$execute if data storage stpa:pending {_$(to_pid):[]} run data remove storage stpa:pending _$(to_pid)
$data remove storage stpa:sent_requests _$(from_pid)
