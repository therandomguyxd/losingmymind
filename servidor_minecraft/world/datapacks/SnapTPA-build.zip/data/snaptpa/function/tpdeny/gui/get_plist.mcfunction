
$execute unless data storage stpa:pending _$(to_pid)[$(parse_index)] run return 0

$execute store result storage stpa:deny from_pid int 1 run data get storage stpa:pending _$(to_pid)[$(parse_index)].from_pid

function snaptpa:tpdeny/gui/get_name with storage stpa:deny

execute if data storage stpa:deny player_name run function snaptpa:tpdeny/gui/actions with storage stpa:deny

data remove storage stpa:deny player_name
data remove storage stpa:deny from_pid

execute store result storage stpa:deny parse_index int 1 run scoreboard players add .parse_index playerID 1

function snaptpa:tpdeny/gui/get_plist with storage stpa:deny
