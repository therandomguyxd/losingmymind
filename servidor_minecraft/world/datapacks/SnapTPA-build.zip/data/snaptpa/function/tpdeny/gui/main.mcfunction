
scoreboard players reset @s stpa.mode

execute store result storage stpa:deny to_pid int 1 run scoreboard players get @s playerID

scoreboard players set .parse_index playerID 0
execute store result storage stpa:deny parse_index int 1 run scoreboard players get .parse_index playerID

function snaptpa:tpdeny/gui/get_plist with storage stpa:deny

playsound minecraft:entity.experience_orb.pickup ambient @s ~ ~ ~ 0.25 1

execute unless data storage stpa:pending_list actions[0] run tellraw @s {translate:"stpa.error.no_teleport_request",fallback:"You Don't Have Any Teleport Request.",color:"red"}
execute if data storage stpa:pending_list actions[0] run function snaptpa:tpdeny/gui/dialog with storage stpa:pending_list

scoreboard players reset .parse_index playerID
data remove storage stpa:pending_list actions
data remove storage stpa:deny to_pid
data remove storage stpa:deny parse_index
data remove storage stpa:deny from_pid
data remove storage stpa:deny player_name
