
execute store result storage stpa:deny from_pid int 1 run scoreboard players get @s stpa.tpdeny
execute store result storage stpa:deny to_pid int 1 run scoreboard players get @s playerID

scoreboard players reset @s stpa.tpdeny

function snaptpa:tpdeny/deny/run with storage stpa:deny

data remove storage stpa:deny from_pid
data remove storage stpa:deny to_pid
