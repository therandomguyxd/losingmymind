
$dialog show @s {type:"minecraft:multi_action",title:{translate:"stpa.dialog.deny.title",fallback:"Teleport Deny"},pause:0b,inputs:[],columns:5,actions:$(actions)}
