
execute store result storage stpa:cancel from_pid int 1 run scoreboard players get @s playerID

function snaptpa:tpcancel/cancel/get_to_pid with storage stpa:cancel

function snaptpa:tpcancel/cancel/run with storage stpa:cancel

data remove storage stpa:cancel from_pid
data remove storage stpa:cancel to_pid
scoreboard players reset @s stpa.tpcancel
