
scoreboard players reset @s stpa.mode

execute store result storage stpa:cancel from_pid int 1 run scoreboard players get @s playerID

function snaptpa:tpcancel/gui/no_pending with storage stpa:cancel

data remove storage stpa:cancel from_pid
data remove storage stpa:cancel to_pid
data remove storage stpa:cancel player_name
