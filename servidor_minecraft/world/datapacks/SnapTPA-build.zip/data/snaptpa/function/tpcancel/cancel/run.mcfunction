
playsound minecraft:entity.experience_orb.pickup ambient @s ~ ~ ~ 0.25 1

$execute unless data storage stpa:sent_requests _$(from_pid) run return run tellraw @s {translate:"stpa.error.no_pending_request",fallback:"You Don't Have Any Pending Request.",color:"red"}

$tellraw @s [{translate:"stpa.cancel.notify_sender.prefix",fallback:"Canceled Teleport Request to ",color:"gold"},{selector:"@a[scores={playerID=$(to_pid)}]",color:"green"},{translate:"stpa.cancel.notify_sender.suffix",fallback:".",color:"gold"}]
$tellraw @a[scores={playerID=$(to_pid)}] [{selector:"@a[scores={playerID=$(from_pid)}]",color:"green"},{translate:"stpa.cancel.notify_receiver.suffix",fallback:" Canceled Their Teleport Request.",color:"gold"}]

$data remove storage stpa:pending _$(to_pid)[{from_pid: $(from_pid)}]
$execute if data storage stpa:pending {_$(to_pid):[]} run data remove storage stpa:pending _$(to_pid)
$data remove storage stpa:sent_requests _$(from_pid)
