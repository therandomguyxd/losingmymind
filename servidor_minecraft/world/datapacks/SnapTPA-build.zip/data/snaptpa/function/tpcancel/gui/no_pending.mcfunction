
playsound minecraft:entity.experience_orb.pickup ambient @s ~ ~ ~ 0.25 1

$execute unless data storage stpa:sent_requests _$(from_pid) run return run tellraw @s {translate:"stpa.error.no_pending_request",fallback:"You Don't Have Any Pending Request.",color:"red"}

$execute store result storage stpa:cancel to_pid int 1 run data get storage stpa:sent_requests _$(from_pid)

function snaptpa:tpcancel/gui/get_name with storage stpa:cancel

function snaptpa:tpcancel/gui/dialog with storage stpa:cancel
