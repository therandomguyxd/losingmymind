
$execute as @a[scores={playerID=$(to_pid)}] at @s run summon text_display ~ ~ ~ {Tags:["stpa.get_name"],text:{"selector":"@a[scores={playerID=$(to_pid)}]"}}

$execute as @a[scores={playerID=$(to_pid)}] at @s run data modify storage stpa:cancel player_name set from entity @n[type=minecraft:text_display,tag=stpa.get_name] text.text

kill @e[type=text_display,tag=stpa.get_name]
