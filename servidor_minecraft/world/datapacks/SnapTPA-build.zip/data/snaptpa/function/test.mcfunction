
dialog show @s {type:"minecraft:multi_action",title:"test",actions:[{label:"test",action:{type:"minecraft:run_command",command:"trigger test set 1"}}]}
