
scoreboard players enable @a stpa.mode
scoreboard players enable @a stpa.tpask.ask
scoreboard players enable @a stpa.tpaccept
scoreboard players enable @a stpa.tpcancel
scoreboard players enable @a stpa.tpdeny

execute as @a[scores={stpa.mode=1}] run function snaptpa:tpask/gui/main

execute as @a[scores={stpa.tpask.ask=1..}] run function snaptpa:tpask/ask/main

execute as @a[scores={stpa.mode=3}] run function snaptpa:tpaccept/gui/main

execute as @a[scores={stpa.tpaccept=1..}] run function snaptpa:tpaccept/accept/main

execute as @a[scores={stpa.mode=2}] run function snaptpa:tpcancel/gui/main

execute as @a[scores={stpa.tpcancel=1}] run function snaptpa:tpcancel/cancel/main

execute as @a[scores={stpa.mode=4}] run function snaptpa:tpdeny/gui/main

execute as @a[scores={stpa.tpdeny=1..}] run function snaptpa:tpdeny/deny/main
