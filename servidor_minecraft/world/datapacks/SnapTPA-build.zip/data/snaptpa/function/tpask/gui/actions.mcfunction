
$data modify storage stpa:player_list actions append value {label:[{player:{name:"$(player_name)"}},"$(player_name)"],width:80,action:{type:"minecraft:run_command",command:"trigger stpa.tpask.ask set $(parse_pid)"}}
