
$dialog show @s {type:"minecraft:multi_action",title:{translate:"stpa.dialog.ask.title",fallback:"Teleport Request"},pause:0b,inputs:[],columns:5,actions:$(actions)}
