
scoreboard players reset @s stpa.mode

scoreboard players set .parse_pid playerID 1

execute store result storage stpa:ask parse_pid int 1 run scoreboard players get .parse_pid playerID

function snaptpa:tpask/gui/get_plist with storage stpa:ask

function snaptpa:tpask/gui/dialog with storage stpa:player_list

scoreboard players reset .parse_pid playerID
data remove storage stpa:player_list actions
data remove storage stpa:ask parse_pid
data remove storage stpa:ask player_name
