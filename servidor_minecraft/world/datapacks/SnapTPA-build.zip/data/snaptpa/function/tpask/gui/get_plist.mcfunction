
$execute as @a[scores={playerID=$(parse_pid)}] at @s run summon text_display ~ ~ ~ {Tags:["stpa.get_name"],text:{"selector":"@n[scores={playerID=$(parse_pid)}]"}}

$execute as @a[scores={playerID=$(parse_pid)}] at @s run data modify storage stpa:ask player_name set from entity @n[type=minecraft:text_display,tag=stpa.get_name] text.text

kill @e[type=text_display,tag=stpa.get_name]

function snaptpa:tpask/gui/actions with storage stpa:ask

data remove storage stpa:ask player_name

execute store result storage stpa:ask parse_pid int 1 run scoreboard players add .parse_pid playerID 1

execute unless score .parse_pid playerID > .currentID playerID run function snaptpa:tpask/gui/get_plist with storage stpa:ask
