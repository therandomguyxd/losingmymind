
playsound minecraft:entity.experience_orb.pickup ambient @s ~ ~ ~ 0.25 1

$execute if score @n[scores={playerID=$(from_pid)}] playerID = @n[scores={playerID=$(to_pid)}] playerID run return run tellraw @a[scores={playerID=$(from_pid)}] [{translate:"stpa.error.tpa_self",fallback:"Can't Teleport to Yourself!",color:"red"}]

$execute if data storage stpa:sent_requests _$(from_pid) run return run tellraw @a[scores={playerID=$(from_pid)}] [{translate:"stpa.error.already_pending",fallback:"You Already Have a Pending Request. Cancel It First.",color:"red"}]

$execute if data storage stpa:pending _$(to_pid)[{from_pid: $(from_pid)}] run return run tellraw @a[scores={playerID=$(from_pid)}] [{translate:"stpa.error.already_sent",fallback:"Already Sent a Request to This Player.",color:"red"}]

$tellraw @a[scores={playerID=$(from_pid)}] [{translate:"stpa.ask.sent",fallback:"Sent Request To ",color:"gold"},{selector:"@a[scores={playerID=$(to_pid)}]",color:"green"},{translate:"stpa.ask.sent.suffix",fallback:"!",color:"gold"}]

$tellraw @a[scores={playerID=$(to_pid)}] [{translate:"stpa.ask.received",fallback:"Received a Request From ",color:"gold"},{selector:"@a[scores={playerID=$(from_pid)}]",color:"green"},{translate:"stpa.ask.received.suffix",fallback:"! ",color:"gold"},{translate:"stpa.ask.accept_button",fallback:"[Accept]",color:"aqua",hover_event:{action:"show_text",value:[{translate:"stpa.ask.accept_button.hover",fallback:"Accept this teleport request",color:"gray"}]},click_event:{action:"run_command",command:"trigger stpa.tpaccept set $(from_pid)"}},{text:" "},{translate:"stpa.ask.deny_button",fallback:"[Deny]",color:"red",hover_event:{action:"show_text",value:[{translate:"stpa.ask.deny_button.hover",fallback:"Deny this teleport request",color:"gray"}]},click_event:{action:"run_command",command:"trigger stpa.tpdeny set $(from_pid)"}}]

$data modify storage stpa:pending _$(to_pid) append value {from_pid: $(from_pid)}

$data modify storage stpa:sent_requests _$(from_pid) set value $(to_pid)
