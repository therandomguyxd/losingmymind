
execute store result storage stpa:ask from_pid int 1 run scoreboard players get @s playerID
execute store result storage stpa:ask to_pid int 1 run scoreboard players get @s stpa.tpask.ask

function snaptpa:tpask/ask/run with storage stpa:ask

data remove storage stpa:ask from_pid
data remove storage stpa:ask to_pid

scoreboard players reset @s stpa.tpask.ask
