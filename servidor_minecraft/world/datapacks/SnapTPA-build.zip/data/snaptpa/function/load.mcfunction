
scoreboard objectives add stpa.mode trigger {text:"Mode",color:"gold"}

scoreboard objectives add stpa.tpask.ask trigger {text:"Ask",color:"gold"}

scoreboard objectives add stpa.tpcancel trigger {text:"Cancel",color:"gold"}

scoreboard objectives add stpa.tpaccept trigger {text:"Accept",color:"gold"}

scoreboard objectives add stpa.tpdeny trigger {text:"Deny",color:"gold"}
