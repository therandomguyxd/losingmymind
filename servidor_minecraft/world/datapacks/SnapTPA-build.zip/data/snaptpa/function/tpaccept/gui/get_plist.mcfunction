
$execute unless data storage stpa:pending _$(to_pid)[$(parse_index)] run return 0

$execute store result storage stpa:accept from_pid int 1 run data get storage stpa:pending _$(to_pid)[$(parse_index)].from_pid

function snaptpa:tpaccept/gui/get_name with storage stpa:accept

execute if data storage stpa:accept player_name run function snaptpa:tpaccept/gui/actions with storage stpa:accept

data remove storage stpa:accept player_name
data remove storage stpa:accept from_pid

execute store result storage stpa:accept parse_index int 1 run scoreboard players add .parse_index playerID 1

function snaptpa:tpaccept/gui/get_plist with storage stpa:accept
