
playsound minecraft:entity.experience_orb.pickup ambient @s ~ ~ ~ 0.25 1

$execute unless data storage stpa:pending _$(to_pid)[{from_pid: $(from_pid)}] run return run tellraw @s {translate:"stpa.error.no_teleport_request",fallback:"You Don't Have Any Teleport Request.",color:"red"}

$tp @a[scores={playerID=$(from_pid)},limit=1] @a[scores={playerID=$(to_pid)},limit=1]

$tellraw @a[scores={playerID=$(from_pid)}] [{selector:"@a[scores={playerID=$(to_pid)}]",color:"green"},{translate:"stpa.accept.notify_sender",fallback:" Accepted Your Teleport Request.",color:"gold"}]
$tellraw @a[scores={playerID=$(to_pid)}] [{translate:"stpa.accept.notify_receiver.prefix",fallback:"Teleported ",color:"gold"},{selector:"@a[scores={playerID=$(from_pid)}]",color:"green"},{translate:"stpa.accept.notify_receiver",fallback:" To Your Position.",color:"gold"}]

$data remove storage stpa:pending _$(to_pid)[{from_pid: $(from_pid)}]
$execute if data storage stpa:pending {_$(to_pid):[]} run data remove storage stpa:pending _$(to_pid)
$data remove storage stpa:sent_requests _$(from_pid)
