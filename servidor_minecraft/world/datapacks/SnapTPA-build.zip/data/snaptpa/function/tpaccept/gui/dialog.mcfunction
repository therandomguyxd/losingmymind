
$dialog show @s {type:"minecraft:multi_action",title:{translate:"stpa.dialog.accept.title",fallback:"Teleport Accept"},pause:0b,inputs:[],columns:5,actions:$(actions)}
