
execute store result storage stpa:accept from_pid int 1 run scoreboard players get @s stpa.tpaccept
execute store result storage stpa:accept to_pid int 1 run scoreboard players get @s playerID

scoreboard players reset @s stpa.tpaccept

function snaptpa:tpaccept/accept/run with storage stpa:accept

data remove storage stpa:accept from_pid
data remove storage stpa:accept to_pid
