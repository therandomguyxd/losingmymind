function pid:uninstall

scoreboard objectives remove stpa.mode
scoreboard objectives remove stpa.tpaccept
scoreboard objectives remove stpa.tpask.ask
scoreboard objectives remove stpa.tpcancel
scoreboard objectives remove stpa.tpdeny