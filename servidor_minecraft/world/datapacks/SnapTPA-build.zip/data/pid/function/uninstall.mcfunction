data remove storage pid:db players
data remove storage pid:db current_pid
scoreboard objectives remove playerID
