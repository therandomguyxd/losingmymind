
scoreboard objectives add playerID dummy [{"text":"Player ID","color":"gold"}]
