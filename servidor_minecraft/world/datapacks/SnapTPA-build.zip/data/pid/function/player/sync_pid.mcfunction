
data modify storage pid:temp player_uuid set from entity @s UUID

function pid:player/get_name

function pid:db/get_pid with storage pid:temp
