
summon text_display ~ ~ ~ {Tags:["pid.get_name"]}
execute as @n[type=minecraft:text_display,tag=pid.get_name] at @s run data modify entity @s text set value {"selector":"@p[scores={playerID=0}]"}

data modify storage pid:temp player_name set from entity @n[type=minecraft:text_display,tag=pid.get_name] text.text

kill @e[type=text_display,tag=pid.get_name]
