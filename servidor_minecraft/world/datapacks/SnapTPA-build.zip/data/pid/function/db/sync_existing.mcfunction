
$data modify storage pid:temp pid set from storage pid:db players[{uuid:$(player_uuid)}].pid

$data modify storage pid:temp name set from storage pid:db players[{uuid:$(player_uuid)}].name

function pid:db/clear_old_name with storage pid:temp

execute store result score @s playerID run data get storage pid:temp pid 1

function pid:player/get_name

$data modify storage pid:db players[{uuid:$(player_uuid)}].name set from storage pid:temp player_name

function pid:db/clear_temp
