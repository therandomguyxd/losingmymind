
$scoreboard players reset $(name) playerID
