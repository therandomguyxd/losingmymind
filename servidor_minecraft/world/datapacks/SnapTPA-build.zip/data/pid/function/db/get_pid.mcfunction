
$execute if data storage pid:db players[{uuid:$(player_uuid)}] run return run function pid:db/sync_existing with storage pid:temp

function pid:db/assign_new
