
scoreboard players add .currentID playerID 1

execute store result storage pid:db current_pid int 1 run scoreboard players get .currentID playerID

scoreboard players operation @s playerID = .currentID playerID

data modify storage pid:temp entry set value {uuid:[I;0,0,0,0],pid:0b, name:""}

data modify storage pid:temp entry.uuid set from storage pid:temp player_uuid

execute store result storage pid:temp entry.pid int 1 run scoreboard players get @s playerID

data modify storage pid:temp entry.name set from storage pid:temp player_name

data modify storage pid:db players append from storage pid:temp entry

function pid:db/clear_temp
