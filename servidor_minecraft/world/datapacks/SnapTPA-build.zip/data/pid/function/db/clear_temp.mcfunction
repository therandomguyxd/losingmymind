data remove storage pid:temp pid
data remove storage pid:temp name
data remove storage pid:temp entry
data remove storage pid:temp player_uuid
data remove storage pid:temp player_name
