
execute as @a at @s unless score @s playerID matches 1.. run scoreboard players set @s playerID 0

execute as @a[scores={playerID=0}] at @s run function pid:player/sync_pid
