

kill @s
