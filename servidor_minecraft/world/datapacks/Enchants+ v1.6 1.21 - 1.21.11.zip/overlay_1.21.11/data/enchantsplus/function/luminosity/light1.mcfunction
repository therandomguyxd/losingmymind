execute align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:marker ~ ~ ~ {Tags:["ep.light1","ep.light.mark1"]}
execute as @e[type=minecraft:marker,tag=ep.light1] at @s run function enchantsplus:luminosity/search1
