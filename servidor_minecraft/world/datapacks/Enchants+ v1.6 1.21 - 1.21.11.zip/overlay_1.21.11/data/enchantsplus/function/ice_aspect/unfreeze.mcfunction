data merge entity @s {NoAI:false}
tag @s remove ep.entity.frozen
playsound minecraft:block.glass.break block @a ~ ~ ~ 1 1

