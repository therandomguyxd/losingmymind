tag @s remove ep.entity.frozen
effect clear @s slowness
summon minecraft:splash_potion ~ ~ ~ {Item:{components:{"minecraft:potion_contents":{potion:"minecraft:water"}},count:1,id:"minecraft:acacia_button"}}