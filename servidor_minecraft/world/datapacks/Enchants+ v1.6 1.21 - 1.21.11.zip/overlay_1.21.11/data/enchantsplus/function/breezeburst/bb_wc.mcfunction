tag @s remove enchantsplus.bb
summon minecraft:wind_charge ^ ^ ^0.05 {Motion:[0d,-1d,0d]}