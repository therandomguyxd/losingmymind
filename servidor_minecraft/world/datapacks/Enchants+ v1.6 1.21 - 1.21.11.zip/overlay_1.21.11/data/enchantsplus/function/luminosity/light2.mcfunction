execute align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:marker ~ ~ ~ {Tags:["ep.light2","ep.light.mark2"]}
execute as @e[type=minecraft:marker,tag=ep.light2] at @s run function enchantsplus:luminosity/search2
