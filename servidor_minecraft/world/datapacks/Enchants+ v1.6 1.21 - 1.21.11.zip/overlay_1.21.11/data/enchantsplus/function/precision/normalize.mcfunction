data merge entity @s {NoGravity:false}
tag @s remove ep.ng1
tag @s remove ep.ng2