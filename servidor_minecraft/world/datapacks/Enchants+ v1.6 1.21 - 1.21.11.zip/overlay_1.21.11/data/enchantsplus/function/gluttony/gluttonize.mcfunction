execute on origin run return fail
data merge entity @s {PickupDelay:0s}
tp @s ~ ~ ~