#search for valid space
execute at @s unless block ~ ~ ~ #enchantsplus:air unless block ~ ~ ~ water[level=0] if block ~ ~1 ~ #enchantsplus:air run tp @s ~ ~1 ~
execute at @s unless block ~ ~ ~ #enchantsplus:air unless block ~ ~ ~ water[level=0] if block ~1 ~ ~ #enchantsplus:air run tp @s ~1 ~ ~
execute at @s unless block ~ ~ ~ #enchantsplus:air unless block ~ ~ ~ water[level=0] if block ~ ~ ~1 #enchantsplus:air run tp @s ~ ~ ~1
execute at @s unless block ~ ~ ~ #enchantsplus:air unless block ~ ~ ~ water[level=0] if block ~-1 ~ ~ #enchantsplus:air run tp @s ~-1 ~ ~
execute at @s unless block ~ ~ ~ #enchantsplus:air unless block ~ ~ ~ water[level=0] run tp @s ~ ~ ~-1
execute at @s unless block ~ ~ ~ #enchantsplus:air unless block ~ ~ ~ water[level=0] run tp @s ~ ~2 ~

#kill invalid markers
execute at @s unless block ~ ~ ~ #enchantsplus:air run kill @s
execute as @s at @s if entity @e[type=marker,tag=ep.light.mark,tag=!ep.light,distance=..0.5] run kill @e[type=marker,tag=ep.light.mark,tag=!ep.light,distance=..0.5]

#place light
execute as @s at @s if block ~ ~ ~ water[level=0] run fill ~ ~ ~ ~ ~ ~ light[waterlogged=true,level=15] replace water
execute as @s at @s unless block ~ ~ ~ water unless block ~ ~ ~ light run fill ~ ~ ~ ~ ~ ~ light[waterlogged=false,level=15] replace #enchantsplus:air


tag @s remove ep.light
