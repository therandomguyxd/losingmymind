execute align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:marker ~ ~ ~ {Tags:["ep.light","ep.light.mark"]}
execute as @e[type=minecraft:marker,tag=ep.light] at @s run function enchantsplus:luminosity/search
