data merge entity @s {NoGravity:true}
execute if data entity @s {weapon:{components:{"minecraft:enchantments":{levels:{"enchantsplus:precision":1}}}}} run tag @s add ep.ng1
execute if data entity @s {weapon:{components:{"minecraft:enchantments":{levels:{"enchantsplus:precision":2}}}}} run tag @s add ep.ng2